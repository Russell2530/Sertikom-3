<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Pendataan Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
        }
        
        .login-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
        }
        
        .btn-primary {
            background: #141414;
            color: white;
            border-radius: 6px;
            transition: all 0.2s ease;
        }
        
        .btn-primary:hover {
            background: #495057;
        }
        
        .input-field {
            border: 1px solid #d1d5db;
            border-radius: 6px;
            transition: all 0.2s ease;
        }
        
        .input-field:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }
        
        .header-bg {
            background: linear-gradient(135deg, #141414 0%, #495057 100%);
        }
    </style>
</head>
<body class="bg-gray-300 min-h-screen flex items-center justify-center p-4">
    <div class="login-container w-full max-w-md">
        <!-- Header -->
        <div class="header-bg text-white p-6 rounded-t-lg">
            <div class="flex items-center space-x-3">
                <i class="fas fa-graduation-cap text-2xl"></i>
                <div>
                    <h1 class="text-xl font-bold">Sistem Pendataan Siswa</h1>
                    <p class="text-blue-100 text-sm">Login ke Akun Anda</p>
                </div>
            </div>
        </div>
        
        <!-- Login Form -->
        <div class="p-6">
            <!-- Session Status -->
            @if (session('status'))
            <div class="mb-4 p-3 bg-green-50 border border-green-200 rounded text-green-700 text-sm">
                {{ session('status') }}
            </div>
            @endif
            
            <form method="POST" action="{{ route('login') }}">
                @csrf
                
                <!-- Email Address -->
                <div class="mb-4">
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">
                        Email
                    </label>
                    <input 
                        id="email" 
                        type="email" 
                        name="email" 
                        value="{{ old('email') }}" 
                        required 
                        autofocus 
                        autocomplete="username"
                        class="input-field w-full px-3 py-2"
                        placeholder="Masukkan email Anda"
                    />
                    @if ($errors->has('email'))
                    <p class="text-red-600 text-xs mt-1">{{ $errors->first('email') }}</p>
                    @endif
                </div>
                
                <!-- Password -->
                <div class="mb-4">
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-1">
                        Password
                    </label>
                    <input 
                        id="password" 
                        type="password" 
                        name="password" 
                        required 
                        autocomplete="current-password"
                        class="input-field w-full px-3 py-2"
                        placeholder="Masukkan password Anda"
                    />
                    @if ($errors->has('password'))
                    <p class="text-red-600 text-xs mt-1">{{ $errors->first('password') }}</p>
                    @endif
                </div>
                
                <!-- Remember Me & Forgot Password -->
                <div class="flex items-center justify-between mb-6">
                    <label class="flex items-center text-sm text-gray-600">
                        <input 
                            id="remember_me" 
                            type="checkbox" 
                            name="remember" 
                            class="rounded border-gray-300 text-blue-600 shadow-sm focus:ring-blue-500 mr-2"
                        />
                        Ingat saya
                    </label>
                    
                    @if (Route::has('password.request'))
                    <a 
                        href="{{ route('password.request') }}" 
                        class="text-sm text-black hover:text-gray-500"
                    >
                        Lupa password?
                    </a>
                    @endif
                </div>
                
                <!-- Login Button -->
                <button type="submit" class="btn-primary w-full py-2 px-4 font-medium">
                    <i class="fas fa-sign-in-alt mr-2"></i>
                    Login
                </button>
            </form>
            
            <!-- Demo Info -->
            <div class="mt-6 p-3 bg-gray-50 border border-gray-200 rounded text-sm text-black>
                <p class="font-medium mb-1">Info Login Demo:</p>
                <p>Email: admin@example.com</p>
                <p>Password: password</p>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="border-t border-gray-200 p-4 text-center text-sm text-black">
            &copy; {{ date('Y') }} Sistem Pendataan Siswa. All rights reserved.
        </div>
    </div>
</body>
</html>