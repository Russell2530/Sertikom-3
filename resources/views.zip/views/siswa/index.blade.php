@extends('layouts.app')

@section('title', 'Siswa')

@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Data Siswa</h1>
    @if(Auth::user()->role !== 'siswa')
        <a href="{{ route('siswa.create') }}" class="btn btn-primary">
            <i class="fas fa-plus"></i> Tambah Siswa
        </a>
    @endif
</div>

<!-- Search & Filter -->
@if(Auth::user()->role !== 'siswa')
<div class="card mb-4">
    <div class="card-body">
        <form action="{{ route('siswa.index') }}" method="GET">
            <div class="row">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Cari nama atau NISN..." 
                           value="{{ request('search') }}">
                </div>
                <div class="col-md-3">
                    <select name="jurusan_id" class="form-select">
                        <option value="">Semua Jurusan</option>
                        @foreach($jurusan as $j)
                            <option value="{{ $j->id }}" {{ request('jurusan_id') == $j->id ? 'selected' : '' }}>
                                {{ $j->nama_jurusan }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="kelas_id" class="form-select">
                        <option value="">Semua Kelas</option>
                        @foreach($kelas as $k)
                            <option value="{{ $k->id }}" {{ request('kelas_id') == $k->id ? 'selected' : '' }}>
                                {{ $k->nama_kelas }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </div>
        </form>
    </div>
</div>
@endif

<div class="card">
    <div class="card-body">
        <!-- Container untuk tabel dan scrollbar -->
        <div class="table-wrapper" id="tableWrapper">
            <!-- Table container dengan overflow hidden -->
            <div class="table-container" id="tableContainer" style="
                width: 100%;
                overflow: hidden;
                border: 1px solid #dee2e6;
                border-radius: 4px 4px 0 0;
                position: relative;
            ">
                <table class="table table-striped mb-0" id="dataTable" style="min-width: 1000px;">
                    <thead>
                        <tr class="text-center">
                            <th style="min-width: 50px;">#</th>
                            <th style="min-width: 70px;">Foto</th>
                            <th style="min-width: 120px;">NISN</th>
                            <th style="min-width: 200px;">Nama Siswa</th>
                            <th style="min-width: 150px;">Jurusan</th>
                            <th style="min-width: 120px;">Kelas</th>
                            <th style="min-width: 120px;">Tahun Ajar</th>
                            @if(Auth::user()->role !== 'siswa')
                            <th style="min-width: 150px;">Aksi</th>
                            @else
                            <th style="min-width: 80px;">Aksi</th>
                            @endif
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($siswa as $item)
                        <tr class="text-center align-middle">
                            <td>{{ $loop->iteration + ($siswa->currentPage() - 1) * $siswa->perPage() }}</td>
                            <td>
                                @if($item->foto)
                                    <img src="{{ asset('storage/' . $item->foto) }}" alt="Foto" class="rounded-circle object-fit-cover" width="40" height="40" style="object-fit: cover;">
                                @else
                                    <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center mx-auto" style="width: 40px; height: 40px;">
                                        <i class="fas fa-user text-white"></i>
                                    </div>
                                @endif
                            </td>
                            <td>{{ $item->nisn }}</td>
                            <td class="text-start">{{ $item->nama_lengkap }}</td>
                            <td>{{ $item->jurusan->nama_jurusan }}</td>
                            <td>{{ $item->kelas->nama_kelas }}</td>
                            <td>{{ $item->tahunAjar->nama_tahun_ajar }}</td>
                            @if(Auth::user()->role !== 'siswa')
                            <td>
                                <div class="btn-group gap-1" role="group" >
                                    <a href="{{ route('siswa.show', $item->id) }}" class="btn btn-info btn-sm" title="Lihat">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="{{ route('siswa.edit', $item->id) }}" class="btn btn-warning btn-sm" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form action="{{ route('siswa.destroy', $item->id) }}" method="POST" class="d-inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" 
                                                onclick="return confirm('Yakin ingin menghapus siswa?')" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                            @else
                            <td>
                                <a href="{{ route('siswa.show', $item->id) }}" class="btn btn-info btn-sm">
                                    <i class="fas fa-eye"></i> Lihat
                                </a>
                            </td>
                            @endif
                        </tr>
                        @empty
                        <tr>
                            <td colspan="{{ Auth::user()->role !== 'siswa' ? 8 : 7 }}" class="text-center py-3">Tidak ada data siswa</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            <!-- Custom Scrollbar Horizontal di bawah tabel -->
            <div class="custom-scrollbar-container" style="
                width: 100%;
                height: 16px;
                background: #f8f9fa;
                border: 1px solid #dee2e6;
                border-top: none;
                border-radius: 0 0 4px 4px;
                position: relative;
                margin-top: -1px;
            ">
                <div class="scroll-track" style="
                    width: 100%;
                    height: 100%;
                    position: relative;
                ">
                    <div class="scroll-thumb" id="scrollThumb" style="
                        height: 10px;
                        background: #6c757d;
                        border-radius: 5px;
                        position: absolute;
                        top: 3px;
                        left: 0;
                        cursor: grab;
                        transition: background-color 0.2s;
                        min-width: 50px;
                    "></div>
                </div>
            </div>
            
            <!-- Tombol navigasi scroll -->
            <div class="scroll-controls mt-2" style="
                display: flex;
                justify-content: center;
                gap: 10px;
            ">
                <button class="btn btn-sm btn-outline-secondary scroll-btn" data-direction="left">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary scroll-btn" data-direction="right">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        </div>
        
        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-3">
            {{ $siswa->links() }}
        </div>
    </div>
</div>

<!-- JavaScript untuk scrollbar custom -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tableContainer = document.getElementById('tableContainer');
    const table = document.getElementById('dataTable');
    const scrollThumb = document.getElementById('scrollThumb');
    const scrollButtons = document.querySelectorAll('.scroll-btn');
    
    // Hitung rasio lebar
    function updateScrollbar() {
        const containerWidth = tableContainer.clientWidth;
        const tableWidth = table.scrollWidth;
        const scrollableWidth = tableWidth - containerWidth;
        
        if (scrollableWidth > 0) {
            // Hitung lebar thumb berdasarkan rasio
            const thumbWidth = Math.max(50, (containerWidth / tableWidth) * containerWidth);
            scrollThumb.style.width = thumbWidth + 'px';
            scrollThumb.style.display = 'block';
            
            // Atur posisi thumb berdasarkan scroll posisi saat ini
            const scrollLeft = tableContainer.scrollLeft;
            const maxScrollLeft = tableWidth - containerWidth;
            const thumbLeft = (scrollLeft / maxScrollLeft) * (containerWidth - thumbWidth);
            scrollThumb.style.left = thumbLeft + 'px';
        } else {
            scrollThumb.style.display = 'none';
        }
    }
    
    // Inisialisasi scrollbar
    updateScrollbar();
    window.addEventListener('resize', updateScrollbar);
    
    // Fungsi untuk drag scroll thumb
    let isDragging = false;
    let startX, startLeft;
    
    scrollThumb.addEventListener('mousedown', function(e) {
        e.preventDefault();
        isDragging = true;
        startX = e.clientX;
        startLeft = parseFloat(scrollThumb.style.left) || 0;
        scrollThumb.style.cursor = 'grabbing';
        scrollThumb.style.backgroundColor = '#495057';
        
        function onMouseMove(e) {
            if (!isDragging) return;
            
            const containerWidth = tableContainer.clientWidth;
            const thumbWidth = scrollThumb.offsetWidth;
            const maxLeft = containerWidth - thumbWidth;
            
            let newLeft = startLeft + (e.clientX - startX);
            newLeft = Math.max(0, Math.min(maxLeft, newLeft));
            
            scrollThumb.style.left = newLeft + 'px';
            
            // Sinkronisasi scroll tabel
            const scrollPercent = newLeft / maxLeft;
            const tableWidth = table.scrollWidth;
            const tableScroll = (tableWidth - containerWidth) * scrollPercent;
            tableContainer.scrollLeft = tableScroll;
        }
        
        function onMouseUp() {
            isDragging = false;
            scrollThumb.style.cursor = 'grab';
            scrollThumb.style.backgroundColor = '#6c757d';
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }
        
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    });
    
    // Sinkronisasi thumb saat tabel di-scroll
    tableContainer.addEventListener('scroll', function() {
        if (isDragging) return;
        
        const containerWidth = tableContainer.clientWidth;
        const tableWidth = table.scrollWidth;
        const thumbWidth = scrollThumb.offsetWidth;
        const maxLeft = containerWidth - thumbWidth;
        
        const scrollLeft = tableContainer.scrollLeft;
        const maxScrollLeft = tableWidth - containerWidth;
        const thumbLeft = maxLeft > 0 ? (scrollLeft / maxScrollLeft) * maxLeft : 0;
        
        scrollThumb.style.left = thumbLeft + 'px';
    });
    
    // Tombol navigasi scroll
    scrollButtons.forEach(button => {
        button.addEventListener('click', function() {
            const direction = this.getAttribute('data-direction');
            const scrollAmount = 150;
            const currentScroll = tableContainer.scrollLeft;
            
            if (direction === 'left') {
                tableContainer.scrollLeft = Math.max(0, currentScroll - scrollAmount);
            } else {
                const maxScroll = table.scrollWidth - tableContainer.clientWidth;
                tableContainer.scrollLeft = Math.min(maxScroll, currentScroll + scrollAmount);
            }
        });
    });
    
    // Hover effect untuk scroll thumb
    scrollThumb.addEventListener('mouseenter', function() {
        if (!isDragging) {
            this.style.backgroundColor = '#495057';
        }
    });
    
    scrollThumb.addEventListener('mouseleave', function() {
        if (!isDragging) {
            this.style.backgroundColor = '#6c757d';
        }
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        
        const currentScroll = tableContainer.scrollLeft;
        const maxScroll = table.scrollWidth - tableContainer.clientWidth;
        
        if (e.key === 'ArrowLeft') {
            e.preventDefault();
            tableContainer.scrollLeft = Math.max(0, currentScroll - 150);
        } else if (e.key === 'ArrowRight') {
            e.preventDefault();
            tableContainer.scrollLeft = Math.min(maxScroll, currentScroll + 150);
        }
    });
});
</script>

<style>
.table-wrapper {
    position: relative;
    width: 100%;
}

.table-container::-webkit-scrollbar {
    display: none;
}

.table-container {
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.scroll-thumb:hover {
    background-color: #495057 !important;
}

.scroll-thumb:active {
    background-color: #343a40 !important;
}

.scroll-btn {
    padding: 2px 10px;
    font-size: 12px;
}

.scroll-btn:hover {
    background-color: #6c757d;
    color: white;
}

/* Styling untuk tabel */
.table th, .table td {
    white-space: nowrap;
    padding: 8px 12px;
    vertical-align: middle;
}

.table-striped tbody tr:nth-of-type(odd) {
    background-color: rgba(0,0,0,.02);
}

.table-striped tbody tr:hover {
    background-color: rgba(0,0,0,.04);
}

/* Styling untuk foto profil */
.object-fit-cover {
    object-fit: cover;
}

/* Styling untuk grup tombol aksi */
.btn-group.gap-1 {
    gap: 4px;
}

.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
}
</style>
@endsection