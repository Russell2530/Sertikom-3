@extends('layouts.app')

@section('title', 'Detail Siswa')

@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Detail Siswa</h1>
    <div class="btn-group">
        <a href="{{ route('siswa.edit', $siswa->id) }}" class="btn btn-warning">
            <i class="fas fa-edit"></i> Edit
        </a>
        <a href="{{ route('siswa.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                @if($siswa->foto)
                    <img src="{{ asset('storage/' . $siswa->foto) }}" alt="Foto Siswa" class="rounded-circle mb-3" width="150" height="150">
                @else
                    <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 150px; height: 150px;">
                        <i class="fas fa-user text-white fa-4x"></i>
                    </div>
                @endif
                <h4>{{ $siswa->nama_lengkap }}</h4>
                <p class="text-muted">NISN: {{ $siswa->nisn }}</p>
                
                <!-- Form Naik Kelas -->
                <div class="mt-4">
                    <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#naikKelasModal">
                        <i class="fas fa-arrow-up"></i> Naik Kelas
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Data Pribadi</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <table class="table table-borderless">
                            <tr>
                                <th width="40%">Nama Lengkap</th>
                                <td>{{ $siswa->nama_lengkap }}</td>
                            </tr>
                            <tr>
                                <th>NISN</th>
                                <td>{{ $siswa->nisn }}</td>
                            </tr>
                            <tr>
                                <th>Jenis Kelamin</th>
                                <td>{{ $siswa->jenis_kelamin == 'laki-laki' ? 'Laki-laki' : 'Perempuan' }}</td>
                            </tr>
                            <tr>
                                <th>Tanggal Lahir</th>
                                <td>{{ \Carbon\Carbon::parse($siswa->tanggal_lahir)->format('d/m/Y') }}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <table class="table table-borderless">
                            <tr>
                                <th width="40%">Alamat</th>
                                <td>{{ $siswa->alamat }}</td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td>{{ $siswa->email ?? '-' }}</td>
                            </tr>
                            <tr>
                                <th>Jurusan</th>
                                <td>{{ $siswa->jurusan->nama_jurusan ?? '-' }}</td>
                            </tr>
                            <tr>
                                <th>Kelas</th>
                                <td>{{ $siswa->kelas->nama_kelas ?? '-' }}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Riwayat Kelas -->
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Riwayat Kelas</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Tahun Ajar</th>
                                <th>Kelas</th>
                                <th>Status</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($riwayatKelas as $riwayat)
                            <tr>
                                <td>{{ $riwayat->tahunAjar->nama_tahun_ajar ?? '-' }}</td>
                                <td>{{ $riwayat->kelas->nama_kelas ?? '-' }}</td>
                                <td>
                                    <span class="badge bg-{{ $riwayat->status == 'aktif' ? 'success' : 'secondary' }}">
                                        {{ $riwayat->status == 'aktif' ? 'Aktif' : 'Nonaktif' }}
                                    </span>
                                </td>
                                <td>{{ $riwayat->created_at->format('d/m/Y H:i') }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Naik Kelas -->
<div class="modal fade" id="naikKelasModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('siswa.naik-kelas', $siswa->id) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Naik Kelas - {{ $siswa->nama_lengkap }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="kelas_id_baru" class="form-label">Kelas Baru</label>
                        <select class="form-select" id="kelas_id_baru" name="kelas_id_baru" required>
                            <option value="">Pilih Kelas Baru</option>
                            @foreach($kelas as $k)
                                <option value="{{ $k->id }}">{{ $k->nama_kelas }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tahun_ajar_id_baru" class="form-label">Tahun Ajar Baru</label>
                        <select class="form-select" id="tahun_ajar_id_baru" name="tahun_ajar_id_baru" required>
                            <option value="">Pilih Tahun Ajar Baru</option>
                            @foreach($tahunAjar as $ta)
                                <option value="{{ $ta->id }}"> {{ $ta->kode_tahun_ajar }} - {{ $ta->nama_tahun_ajar }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Naik Kelas</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    // Auto close alert setelah 5 detik
    setTimeout(function() {
        $('.alert').alert('close');
    }, 5000);
</script>
@endpush