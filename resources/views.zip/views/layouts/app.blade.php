<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title') - Sistem Pendataan Siswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .sidebar .nav-link {
            color: #fff;
            transition: all 0.3s ease;
            padding: 12px 20px;
            border-radius: 8px;
            margin: 4px 8px;
        }
        .sidebar .nav-link:hover {
            background-color: #495057;
            transform: translateX(5px);
        }
        .sidebar .nav-link.active {
            background-color: #007bff;
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
        }
        .sidebar .nav-link i {
            transition: transform 0.3s ease;
        }
        .sidebar .nav-link:hover i {
            transform: scale(1.1);
        }
        .navbar-brand {
            font-weight: bold;
        }
        
        /* Mobile Sidebar Overlay */
        .sidebar-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1040;
            opacity: 0;
            visibility: hidden;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            backdrop-filter: blur(3px);
        }
        
        .sidebar-overlay.show {
            opacity: 1;
            visibility: visible;
        }
        
        .sidebar.show {
            transform: translateX(0);
            box-shadow: 5px 0 25px rgba(0, 0, 0, 0.3);
        }
        
        /* Mobile Sidebar */
        @media (max-width: 768px) {
            .sidebar {
                position: fixed;
                top: 0;
                left: 0;
                width: 280px;
                height: 100vh;
                z-index: 1050;
                transform: translateX(-100%);
            }
            
            .mobile-sidebar-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                background: linear-gradient(135deg, #343a40 0%, #2c3136 100%);
                border-bottom: 1px solid #495057;
                padding: 1.2rem 1.5rem;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            }
            
            .main-content {
                margin-left: 0 !important;
                transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            }
            
            body.sidebar-open .main-content {
                filter: blur(2px);
            }
        }
        
        /* Desktop sidebar */
        @media (min-width: 769px) {
            .sidebar {
                transform: translateX(0) !important;
                box-shadow: none !important;
            }
            
            .mobile-sidebar-header {
                display: none !important;
            }
        }
        
        /* Close button styling */
        .btn-sidebar-close {
            color: #fff;
            font-size: 1.3rem;
            background: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
        }
        
        .btn-sidebar-close:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: rotate(90deg) scale(1.1);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }
        
        /* Mobile menu toggle button */
        .navbar-toggler {
            border: 1px solid rgba(0, 0, 0, 0.1);
            padding: 8px 12px;
            border-radius: 8px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .navbar-toggler:hover {
            background-color: rgba(0, 0, 0, 0.05);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .navbar-toggler:active {
            transform: translateY(0);
        }
        
        .navbar-toggler-icon {
            width: 1.5em;
            height: 1.5em;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.7)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
        }
        
        .navbar-toggler.open .navbar-toggler-icon {
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba(0, 0, 0, 0.7)' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M6 6L24 24M6 24L24 6'/%3e%3c/svg%3e");
            transform: rotate(180deg);
        }
        
        /* Menu title */
        .mobile-menu-title {
            color: #fff;
            font-size: 1.3rem;
            font-weight: 600;
            margin: 0;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }
        
        /* Menu item animation */
        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .sidebar.show .nav-item {
            animation: slideInLeft 0.4s cubic-bezier(0.4, 0, 0.2, 1) forwards;
            opacity: 0;
        }
        
        .sidebar.show .nav-item:nth-child(1) { animation-delay: 0.1s; }
        .sidebar.show .nav-item:nth-child(2) { animation-delay: 0.15s; }
        .sidebar.show .nav-item:nth-child(3) { animation-delay: 0.2s; }
        .sidebar.show .nav-item:nth-child(4) { animation-delay: 0.25s; }
        .sidebar.show .nav-item:nth-child(5) { animation-delay: 0.3s; }
        .sidebar.show .nav-item:nth-child(6) { animation-delay: 0.35s; }
        .sidebar.show .nav-item:nth-child(7) { animation-delay: 0.4s; }
        .sidebar.show .nav-item:nth-child(8) { animation-delay: 0.45s; }
        
        /* Navbar user dropdown */
        .dropdown-toggle {
            transition: all 0.3s ease;
        }
        
        .dropdown-toggle:hover {
            transform: translateY(-1px);
        }
        
        /* Content area */
        .main-content {
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        /* Alert animations */
        .alert {
            animation: slideInDown 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        @keyframes slideInDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Badge styling */
        .badge {
            transition: all 0.3s ease;
        }
        
        .badge:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        /* Smooth scrollbar for sidebar */
        .sidebar::-webkit-scrollbar {
            width: 6px;
        }
        
        .sidebar::-webkit-scrollbar-track {
            background: #2c3136;
        }
        
        .sidebar::-webkit-scrollbar-thumb {
            background: #495057;
            border-radius: 3px;
        }
        
        .sidebar::-webkit-scrollbar-thumb:hover {
            background: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <!-- Mobile Sidebar Overlay -->
        <div class="sidebar-overlay" id="sidebarOverlay"></div>
        
        <div class="row">
            <!-- Sidebar -->
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block sidebar collapse">
                <!-- Mobile Sidebar Header -->
                <div class="mobile-sidebar-header">
                    <h5 class="mobile-menu-title">Menu Navigasi</h5>
                    <button class="btn-sidebar-close" type="button" id="mobileSidebarClose" aria-label="Tutup menu">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link {{ Request::is('dashboard') ? 'active' : '' }}" href="{{ route('dashboard') }}">
                                <i class="fas fa-tachometer-alt me-2"></i>
                                Dashboard
                            </a>
                        </li>
                        @if(Auth::user()->role !== 'siswa')
                        <li class="nav-item">
                            <a class="nav-link {{ Request::is('tahun-ajar*') ? 'active' : '' }}" href="{{ route('tahun-ajar.index') }}">
                                <i class="fas fa-calendar-alt me-2"></i>
                                Tahun Ajar
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ Request::is('jurusan*') ? 'active' : '' }}" href="{{ route('jurusan.index') }}">
                                <i class="fas fa-graduation-cap me-2"></i>
                                Jurusan
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ Request::is('kelas*') ? 'active' : '' }}" href="{{ route('kelas.index') }}">
                                <i class="fas fa-school me-2"></i>
                                Kelas
                            </a>
                        </li>
                        @endif
                        
                        <!-- Menu Siswa hanya untuk admin & guru -->
                        @if(Auth::user()->role !== 'siswa')
                        <li class="nav-item">
                            <a class="nav-link {{ Request::is('siswa*') ? 'active' : '' }}" href="{{ route('siswa.index') }}">
                                <i class="fas fa-users me-2"></i>
                                Siswa
                            </a>
                        </li>
                        @endif
                        
                        @if(Auth::user()->role === 'admin')
                        <li class="nav-item">
                            <a class="nav-link {{ Request::is('users*') ? 'active' : '' }}" href="{{ route('users.index') }}">
                                <i class="fas fa-user-cog me-2"></i>
                                Manajemen User
                            </a>
                        </li>
                        @endif
                    </ul>
                </div>
            </nav>

            <!-- Main content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
                <!-- Navbar -->
                <nav class="navbar navbar-expand-lg navbar-light bg-light mb-4 shadow-sm">
                    <div class="container-fluid">
                        <button class="navbar-toggler" type="button" id="mobileSidebarToggle" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                            <span class="ms-2 d-none d-sm-inline fw-medium">Menu</span>
                        </button>
                        <span class="navbar-brand">Sistem Pendataan Siswa</span>
                        <div class="navbar-nav ms-auto">
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-user-circle me-1"></i>
                                    {{ Auth::user()->name }}
                                    <span class="badge bg-{{ Auth::user()->role === 'admin' ? 'danger' : (Auth::user()->role === 'guru' ? 'warning' : 'success') }}">
                                        {{ ucfirst(Auth::user()->role) }}
                                    </span>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end shadow border-0">
                                    <li>
                                        <form method="POST" action="{{ route('logout') }}">
                                            @csrf
                                            <button type="submit" class="dropdown-item d-flex align-items-center">
                                                <i class="fas fa-sign-out-alt me-2"></i>Logout
                                            </button>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        </div>
                    </div>
                </nav>

                <!-- Content -->
                <div class="container-fluid">
                    @if(session('success'))
                        <div class="alert alert-success alert-dismissible fade show shadow-sm" role="alert">
                            <i class="fas fa-check-circle me-2"></i>
                            {{ session('success') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    @if(session('error'))
                        <div class="alert alert-danger alert-dismissible fade show shadow-sm" role="alert">
                            <i class="fas fa-exclamation-circle me-2"></i>
                            {{ session('error') }}
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    @endif

                    @yield('content')
                </div>
            </main>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const sidebarOverlay = document.getElementById('sidebarOverlay');
            const mobileSidebarToggle = document.getElementById('mobileSidebarToggle');
            const mobileSidebarClose = document.getElementById('mobileSidebarClose');
            const navLinks = document.querySelectorAll('#sidebar .nav-link');
            const body = document.body;
            
            let isSidebarOpen = false;
            
            // Toggle sidebar on mobile
            mobileSidebarToggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (!isSidebarOpen) {
                    openSidebar();
                } else {
                    closeSidebar();
                }
            });
            
            // Close sidebar with close button
            mobileSidebarClose.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                closeSidebar();
            });
            
            // Close sidebar when clicking on overlay
            sidebarOverlay.addEventListener('click', function(e) {
                if (e.target === sidebarOverlay) {
                    closeSidebar();
                }
            });
            
            // Close sidebar when clicking on nav links (mobile only)
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    if (window.innerWidth < 768) {
                        setTimeout(() => {
                            closeSidebar();
                        }, 300);
                    }
                });
            });
            
            // Open sidebar function with animation
            function openSidebar() {
                sidebar.classList.add('show');
                sidebarOverlay.classList.add('show');
                body.classList.add('sidebar-open');
                mobileSidebarToggle.classList.add('open');
                isSidebarOpen = true;
                
                // Lock body scroll
                body.style.overflow = 'hidden';
            }
            
            // Close sidebar function with animation
            function closeSidebar() {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('show');
                body.classList.remove('sidebar-open');
                mobileSidebarToggle.classList.remove('open');
                isSidebarOpen = false;
                
                // Unlock body scroll
                body.style.overflow = '';
            }
            
            // Close sidebar on window resize (if resized to desktop)
            function handleResize() {
                if (window.innerWidth >= 768) {
                    // Reset all states on desktop
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('show');
                    body.classList.remove('sidebar-open');
                    mobileSidebarToggle.classList.remove('open');
                    body.style.overflow = '';
                    isSidebarOpen = false;
                }
            }
            
            window.addEventListener('resize', handleResize);
            
            // Close sidebar with escape key
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && isSidebarOpen) {
                    closeSidebar();
                }
            });
            
            // Prevent Bootstrap from interfering with our custom sidebar
            mobileSidebarToggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                return false;
            });
            
            // Smooth scroll to top when clicking active links
            document.querySelectorAll('.nav-link.active').forEach(link => {
                link.addEventListener('click', function(e) {
                    if (this.getAttribute('href') === window.location.pathname) {
                        e.preventDefault();
                        window.scrollTo({
                            top: 0,
                            behavior: 'smooth'
                        });
                    }
                });
            });
            
            // Add hover effect to dropdown
            const dropdownToggle = document.querySelector('.dropdown-toggle');
            if (dropdownToggle) {
                dropdownToggle.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-2px)';
                });
                
                dropdownToggle.addEventListener('mouseleave', function() {
                    this.style.transform = '';
                });
            }
        });
    </script>
    @stack('scripts')
</body>
</html>