@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Dashboard</h1>
</div>

<div class="row">
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5 class="card-title">Total Siswa</h5>
                        <h2 class="mb-0">{{ $totalSiswa }}</h2>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-users fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-success">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5 class="card-title">Total Jurusan</h5>
                        <h2 class="mb-0">{{ $totalJurusan }}</h2>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-graduation-cap fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5 class="card-title">Total Kelas</h5>
                        <h2 class="mb-0">{{ $totalKelas }}</h2>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-school fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-4">
        <div class="card text-white bg-info">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h5 class="card-title">Total User</h5>
                        <h2 class="mb-0">{{ $totalUser }}</h2>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-user-cog fa-2x"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Selamat Datang, {{ Auth::user()->name }}!</h5>
            </div>
            <div class="card-body">
                <p>Anda login sebagai <strong>{{ ucfirst(Auth::user()->role) }}</strong></p>
                @if(Auth::user()->role === 'siswa')
                    <p>Silakan gunakan menu untuk melihat data akademik Anda.</p>
                @else
                    <p>Silakan gunakan menu sidebar untuk mengelola data sekolah.</p>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- Tabel Siswa Terbaru -->
<div class="row mt-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Data Siswa Terbaru</h5>
            </div>
            <div class="card-body">
                <!-- Search Form -->
                <form action="{{ route('dashboard') }}" method="GET" class="mb-4">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" placeholder="Cari NISN atau nama..." value="{{ request('search') }}">
                                <button class="btn btn-outline-secondary" type="submit">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <select name="jurusan_id" class="form-select">
                                <option value="">Semua Jurusan</option>
                                @foreach($jurusan as $j)
                                    <option value="{{ $j->id }}" {{ request('jurusan_id') == $j->id ? 'selected' : '' }}>
                                        {{ $j->nama_jurusan }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select name="kelas_id" class="form-select">
                                <option value="">Semua Kelas</option>
                                @foreach($kelas as $k)
                                    <option value="{{ $k->id }}" {{ request('kelas_id') == $k->id ? 'selected' : '' }}>
                                        {{ $k->nama_kelas }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">Filter</button>
                            @if(request()->hasAny(['search', 'jurusan_id', 'kelas_id']))
                                <a href="{{ route('dashboard') }}" class="btn btn-secondary w-100 mt-2">Reset</a>
                            @endif
                        </div>
                    </div>
                </form>

                <!-- Container untuk tabel dan scrollbar -->
                <div class="table-wrapper" id="tableWrapper">
                    <!-- Table container dengan overflow hidden -->
                    <div class="table-container" id="tableContainer" style="
                        width: 100%;
                        overflow: hidden;
                        border: 1px solid #dee2e6;
                        border-radius: 4px 4px 0 0;
                        position: relative;
                    ">
                        <table class="table table-striped table-hover mb-0" id="dataTable" style="min-width: 900px;">
                            <thead>
                                <tr class="text-center">
                                    <th class="text-nowrap bg-light">No</th>
                                    <th class="text-nowrap bg-light">NISN</th>
                                    <th class="text-nowrap bg-light">Nama Lengkap</th>
                                    <th class="text-nowrap bg-light">Jenis Kelamin</th>
                                    <th class="text-nowrap bg-light">Jurusan</th>
                                    <th class="text-nowrap bg-light">Kelas</th>
                                    <th class="text-nowrap bg-light">Tahun Ajar</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($recentSiswa as $siswa)
                                <tr class="text-center">
                                    <td class="text-nowrap">{{ $loop->iteration }}</td>
                                    <td class="text-nowrap">{{ $siswa->nisn }}</td>
                                    <td class="text-nowrap">{{ $siswa->nama_lengkap }}</td>
                                    <td class="text-nowrap">{{ $siswa->jenis_kelamin == 'laki-laki' ? 'Laki-laki' : 'Perempuan' }}</td>
                                    <td class="text-nowrap">{{ $siswa->jurusan->nama_jurusan ?? '-' }}</td>
                                    <td class="text-nowrap">{{ $siswa->kelas->nama_kelas ?? '-' }}</td>
                                    <td class="text-nowrap">{{ $siswa->tahunAjar->nama_tahun_ajar ?? '-' }}</td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="7" class="text-center py-3">Tidak ada data siswa</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Custom Scrollbar Horizontal di bawah tabel -->
                    <div class="custom-scrollbar-container" style="
                        width: 100%;
                        height: 16px;
                        background: #f8f9fa;
                        border: 1px solid #dee2e6;
                        border-top: none;
                        border-radius: 0 0 4px 4px;
                        position: relative;
                    ">
                        <div class="scroll-track" style="
                            width: 100%;
                            height: 100%;
                            position: relative;
                        ">
                            <div class="scroll-thumb" id="scrollThumb" style="
                                height: 10px;
                                background: #6c757d;
                                border-radius: 5px;
                                position: absolute;
                                top: 3px;
                                left: 0;
                                cursor: grab;
                                transition: background-color 0.2s;
                                min-width: 50px;
                            "></div>
                        </div>
                    </div>
                    
                    <!-- Tombol navigasi scroll -->
                    <div class="scroll-controls mt-2" style="
                        display: flex;
                        justify-content: center;
                        gap: 10px;
                    ">
                        <button class="btn btn-sm btn-outline-secondary scroll-btn" data-direction="left">
                            <i class="fas fa-chevron-left"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-secondary scroll-btn" data-direction="right">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
                
                @if($recentSiswa->count() > 0)
                    <div class="mt-3 text-center">
                        <a href="{{ route('siswa.index') }}" class="btn btn-primary btn-sm">
                            Lihat Semua Siswa
                        </a>
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>

<!-- JavaScript untuk scrollbar custom -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tableContainer = document.getElementById('tableContainer');
    const table = document.getElementById('dataTable');
    const scrollThumb = document.getElementById('scrollThumb');
    const scrollButtons = document.querySelectorAll('.scroll-btn');
    
    // Hitung rasio lebar
    function updateScrollbar() {
        const containerWidth = tableContainer.clientWidth;
        const tableWidth = table.scrollWidth;
        const scrollableWidth = tableWidth - containerWidth;
        
        if (scrollableWidth > 0) {
            // Hitung lebar thumb berdasarkan rasio
            const thumbWidth = Math.max(50, (containerWidth / tableWidth) * containerWidth);
            scrollThumb.style.width = thumbWidth + 'px';
            scrollThumb.style.display = 'block';
            
            // Atur posisi thumb berdasarkan scroll posisi saat ini
            const scrollLeft = tableContainer.scrollLeft;
            const maxScrollLeft = tableWidth - containerWidth;
            const thumbLeft = (scrollLeft / maxScrollLeft) * (containerWidth - thumbWidth);
            scrollThumb.style.left = thumbLeft + 'px';
        } else {
            scrollThumb.style.display = 'none';
        }
    }
    
    // Inisialisasi scrollbar
    updateScrollbar();
    window.addEventListener('resize', updateScrollbar);
    
    // Fungsi untuk drag scroll thumb
    let isDragging = false;
    let startX, startLeft;
    
    scrollThumb.addEventListener('mousedown', function(e) {
        e.preventDefault();
        isDragging = true;
        startX = e.clientX;
        startLeft = parseFloat(scrollThumb.style.left) || 0;
        scrollThumb.style.cursor = 'grabbing';
        scrollThumb.style.backgroundColor = '#495057';
        
        function onMouseMove(e) {
            if (!isDragging) return;
            
            const containerWidth = tableContainer.clientWidth;
            const thumbWidth = scrollThumb.offsetWidth;
            const maxLeft = containerWidth - thumbWidth;
            
            let newLeft = startLeft + (e.clientX - startX);
            newLeft = Math.max(0, Math.min(maxLeft, newLeft));
            
            scrollThumb.style.left = newLeft + 'px';
            
            // Sinkronisasi scroll tabel
            const scrollPercent = newLeft / maxLeft;
            const tableWidth = table.scrollWidth;
            const tableScroll = (tableWidth - containerWidth) * scrollPercent;
            tableContainer.scrollLeft = tableScroll;
        }
        
        function onMouseUp() {
            isDragging = false;
            scrollThumb.style.cursor = 'grab';
            scrollThumb.style.backgroundColor = '#6c757d';
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }
        
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    });
    
    // Sinkronisasi thumb saat tabel di-scroll
    tableContainer.addEventListener('scroll', function() {
        if (isDragging) return;
        
        const containerWidth = tableContainer.clientWidth;
        const tableWidth = table.scrollWidth;
        const thumbWidth = scrollThumb.offsetWidth;
        const maxLeft = containerWidth - thumbWidth;
        
        const scrollLeft = tableContainer.scrollLeft;
        const maxScrollLeft = tableWidth - containerWidth;
        const thumbLeft = maxLeft > 0 ? (scrollLeft / maxScrollLeft) * maxLeft : 0;
        
        scrollThumb.style.left = thumbLeft + 'px';
    });
    
    // Tombol navigasi scroll
    scrollButtons.forEach(button => {
        button.addEventListener('click', function() {
            const direction = this.getAttribute('data-direction');
            const scrollAmount = 100;
            const currentScroll = tableContainer.scrollLeft;
            
            if (direction === 'left') {
                tableContainer.scrollLeft = Math.max(0, currentScroll - scrollAmount);
            } else {
                const maxScroll = table.scrollWidth - tableContainer.clientWidth;
                tableContainer.scrollLeft = Math.min(maxScroll, currentScroll + scrollAmount);
            }
        });
    });
    
    // Hover effect untuk scroll thumb
    scrollThumb.addEventListener('mouseenter', function() {
        if (!isDragging) {
            this.style.backgroundColor = '#495057';
        }
    });
    
    scrollThumb.addEventListener('mouseleave', function() {
        if (!isDragging) {
            this.style.backgroundColor = '#6c757d';
        }
    });
});
</script>

<style>
.table-wrapper {
    position: relative;
    width: 100%;
}

.table-container::-webkit-scrollbar {
    display: none;
}

.table-container {
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.scroll-thumb:hover {
    background-color: #495057 !important;
}

.scroll-thumb:active {
    background-color: #343a40 !important;
}

.scroll-btn {
    padding: 2px 10px;
    font-size: 12px;
}

.scroll-btn:hover {
    background-color: #6c757d;
    color: white;
}
</style>

@endsection