@extends('layouts.app')

@section('title', 'Manajemen User')

@section('content')
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Manajemen User</h1>
    <a href="{{ route('users.create') }}" class="btn btn-primary">
        <i class="fas fa-plus"></i> Tambah User
    </a>
</div>

<div class="card">
    <div class="card-body">
        <!-- Container untuk tabel dan scrollbar -->
        <div class="table-wrapper" id="tableWrapper">
            <!-- Table container dengan overflow hidden -->
            <div class="table-container" id="tableContainer" style="
                width: 100%;
                overflow: hidden;
                border: 1px solid #dee2e6;
                border-radius: 4px 4px 0 0;
                position: relative;
            ">
                <table class="table table-striped mb-0" id="dataTable" style="min-width: 800px;">
                    <thead>
                        <tr class="text-center">
                            <th style="min-width: 50px;">#</th>
                            <th style="min-width: 150px;">Nama</th>
                            <th style="min-width: 200px;">Email</th>
                            <th style="min-width: 100px;">Role</th>
                            <th style="min-width: 120px;">Dibuat</th>
                            <th style="min-width: 120px;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($users as $user)
                        <tr class="text-center align-middle">
                            <td>{{ $loop->iteration }}</td>
                            <td class="text-start">{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>
                            <td>
                                <span class="badge bg-{{ $user->role == 'admin' ? 'danger' : ($user->role == 'guru' ? 'warning' : 'success') }}">
                                    {{ ucfirst($user->role) }}
                                </span>
                            </td>
                            <td>{{ $user->created_at->format('d/m/Y') }}</td>
                            <td>
                                <div class="btn-group gap-1" role="group">
                                    <a href="{{ route('users.edit', $user->id) }}" class="btn btn-warning btn-sm" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    @if($user->id != auth()->id())
                                    <form action="{{ route('users.destroy', $user->id) }}" method="POST" class="d-inline">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm" 
                                                onclick="return confirm('Yakin ingin menghapus user?')" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                    @endif
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            
            <!-- Custom Scrollbar Horizontal di bawah tabel -->
            <div class="custom-scrollbar-container" style="
                width: 100%;
                height: 16px;
                background: #f8f9fa;
                border: 1px solid #dee2e6;
                border-top: none;
                border-radius: 0 0 4px 4px;
                position: relative;
                margin-top: -1px;
            ">
                <div class="scroll-track" style="
                    width: 100%;
                    height: 100%;
                    position: relative;
                ">
                    <div class="scroll-thumb" id="scrollThumb" style="
                        height: 10px;
                        background: #6c757d;
                        border-radius: 5px;
                        position: absolute;
                        top: 3px;
                        left: 0;
                        cursor: grab;
                        transition: background-color 0.2s;
                        min-width: 50px;
                    "></div>
                </div>
            </div>
            
            <!-- Tombol navigasi scroll -->
            <div class="scroll-controls mt-2" style="
                display: flex;
                justify-content: center;
                gap: 10px;
            ">
                <button class="btn btn-sm btn-outline-secondary scroll-btn" data-direction="left">
                    <i class="fas fa-chevron-left"></i>
                </button>
                <button class="btn btn-sm btn-outline-secondary scroll-btn" data-direction="right">
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        </div>
        
        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-3">
            {{ $users->links() }}
        </div>
    </div>
</div>

<!-- JavaScript untuk scrollbar custom -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const tableContainer = document.getElementById('tableContainer');
    const table = document.getElementById('dataTable');
    const scrollThumb = document.getElementById('scrollThumb');
    const scrollButtons = document.querySelectorAll('.scroll-btn');
    
    // Hitung rasio lebar
    function updateScrollbar() {
        const containerWidth = tableContainer.clientWidth;
        const tableWidth = table.scrollWidth;
        const scrollableWidth = tableWidth - containerWidth;
        
        if (scrollableWidth > 0) {
            // Hitung lebar thumb berdasarkan rasio
            const thumbWidth = Math.max(50, (containerWidth / tableWidth) * containerWidth);
            scrollThumb.style.width = thumbWidth + 'px';
            scrollThumb.style.display = 'block';
            
            // Atur posisi thumb berdasarkan scroll posisi saat ini
            const scrollLeft = tableContainer.scrollLeft;
            const maxScrollLeft = tableWidth - containerWidth;
            const thumbLeft = (scrollLeft / maxScrollLeft) * (containerWidth - thumbWidth);
            scrollThumb.style.left = thumbLeft + 'px';
        } else {
            scrollThumb.style.display = 'none';
        }
    }
    
    // Inisialisasi scrollbar
    updateScrollbar();
    window.addEventListener('resize', updateScrollbar);
    
    // Fungsi untuk drag scroll thumb
    let isDragging = false;
    let startX, startLeft;
    
    scrollThumb.addEventListener('mousedown', function(e) {
        e.preventDefault();
        isDragging = true;
        startX = e.clientX;
        startLeft = parseFloat(scrollThumb.style.left) || 0;
        scrollThumb.style.cursor = 'grabbing';
        scrollThumb.style.backgroundColor = '#495057';
        
        function onMouseMove(e) {
            if (!isDragging) return;
            
            const containerWidth = tableContainer.clientWidth;
            const thumbWidth = scrollThumb.offsetWidth;
            const maxLeft = containerWidth - thumbWidth;
            
            let newLeft = startLeft + (e.clientX - startX);
            newLeft = Math.max(0, Math.min(maxLeft, newLeft));
            
            scrollThumb.style.left = newLeft + 'px';
            
            // Sinkronisasi scroll tabel
            const scrollPercent = newLeft / maxLeft;
            const tableWidth = table.scrollWidth;
            const tableScroll = (tableWidth - containerWidth) * scrollPercent;
            tableContainer.scrollLeft = tableScroll;
        }
        
        function onMouseUp() {
            isDragging = false;
            scrollThumb.style.cursor = 'grab';
            scrollThumb.style.backgroundColor = '#6c757d';
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        }
        
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    });
    
    // Sinkronisasi thumb saat tabel di-scroll
    tableContainer.addEventListener('scroll', function() {
        if (isDragging) return;
        
        const containerWidth = tableContainer.clientWidth;
        const tableWidth = table.scrollWidth;
        const thumbWidth = scrollThumb.offsetWidth;
        const maxLeft = containerWidth - thumbWidth;
        
        const scrollLeft = tableContainer.scrollLeft;
        const maxScrollLeft = tableWidth - containerWidth;
        const thumbLeft = maxLeft > 0 ? (scrollLeft / maxScrollLeft) * maxLeft : 0;
        
        scrollThumb.style.left = thumbLeft + 'px';
    });
    
    // Tombol navigasi scroll
    scrollButtons.forEach(button => {
        button.addEventListener('click', function() {
            const direction = this.getAttribute('data-direction');
            const scrollAmount = 100;
            const currentScroll = tableContainer.scrollLeft;
            
            if (direction === 'left') {
                tableContainer.scrollLeft = Math.max(0, currentScroll - scrollAmount);
            } else {
                const maxScroll = table.scrollWidth - tableContainer.clientWidth;
                tableContainer.scrollLeft = Math.min(maxScroll, currentScroll + scrollAmount);
            }
        });
    });
    
    // Hover effect untuk scroll thumb
    scrollThumb.addEventListener('mouseenter', function() {
        if (!isDragging) {
            this.style.backgroundColor = '#495057';
        }
    });
    
    scrollThumb.addEventListener('mouseleave', function() {
        if (!isDragging) {
            this.style.backgroundColor = '#6c757d';
        }
    });
    
    // Keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        
        const currentScroll = tableContainer.scrollLeft;
        const maxScroll = table.scrollWidth - tableContainer.clientWidth;
        
        if (e.key === 'ArrowLeft') {
            e.preventDefault();
            tableContainer.scrollLeft = Math.max(0, currentScroll - 100);
        } else if (e.key === 'ArrowRight') {
            e.preventDefault();
            tableContainer.scrollLeft = Math.min(maxScroll, currentScroll + 100);
        }
    });
});
</script>

<style>
.table-wrapper {
    position: relative;
    width: 100%;
}

.table-container::-webkit-scrollbar {
    display: none;
}

.table-container {
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.scroll-thumb:hover {
    background-color: #495057 !important;
}

.scroll-thumb:active {
    background-color: #343a40 !important;
}

.scroll-btn {
    padding: 2px 10px;
    font-size: 12px;
}

.scroll-btn:hover {
    background-color: #6c757d;
    color: white;
}

/* Styling untuk tabel */
.table th, .table td {
    white-space: nowrap;
    padding: 8px 12px;
    vertical-align: middle;
}

.table-striped tbody tr:nth-of-type(odd) {
    background-color: rgba(0,0,0,.02);
}

.table-striped tbody tr:hover {
    background-color: rgba(0,0,0,.04);
}

/* Styling untuk badge role */
.badge {
    padding: 4px 8px;
    font-size: 0.8em;
    font-weight: 500;
}

.bg-danger { background-color: #dc3545 !important; }
.bg-warning { background-color: #ffc107 !important; color: #000 !important; }
.bg-success { background-color: #198754 !important; }

/* Styling untuk grup tombol aksi */
.btn-group.gap-1 {
    gap: 4px;
}

.btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.875rem;
}

/* Styling untuk kolom nama */
.text-start {
    text-align: left !important;
}
</style>
@endsection